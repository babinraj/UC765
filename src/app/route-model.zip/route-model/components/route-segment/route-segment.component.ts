import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route-segment',
  templateUrl: './route-segment.component.html',
  styleUrls: ['./route-segment.component.scss']
})
export class RouteSegmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
