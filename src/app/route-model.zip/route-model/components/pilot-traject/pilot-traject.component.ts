import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pilot-traject',
  templateUrl: './pilot-traject.component.html',
  styleUrls: ['./pilot-traject.component.scss']
})
export class PilotTrajectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
