import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hydro-meteo',
  templateUrl: './hydro-meteo.component.html',
  styleUrls: ['./hydro-meteo.component.scss']
})
export class HydroMeteoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
