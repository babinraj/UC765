import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cbs-location',
  templateUrl: './cbs-location.component.html',
  styleUrls: ['./cbs-location.component.scss']
})
export class CbsLocationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
