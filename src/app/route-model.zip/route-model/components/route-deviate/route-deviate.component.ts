import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route-deviate',
  templateUrl: './route-deviate.component.html',
  styleUrls: ['./route-deviate.component.scss']
})
export class RouteDeviateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
